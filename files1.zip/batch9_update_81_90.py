# -*- coding: utf-8 -*-
"""배치 9: ID 81~90 레시피 상세 업데이트"""
import psycopg2
import json

DB_URL = "postgresql://postgres:WIjbfaRGbyRnfKhKCkpRwggjMLRGbsmj@mainline.proxy.rlwy.net:14763/railway"

RECIPES = [
    {"id": 81, "difficulty": 2, "cook_time_min": 30, "servings": 2,
     "tags": ["조림", "닭", "매운맛", "반찬"],
     "steps": [
         {"step": 1, "text": "닭날개(윙+봉) 500g을 깨끗이 씻고 칼집을 2~3번 넣는다"},
         {"step": 2, "text": "끓는 물에 닭날개를 2분 데쳐 핏물을 빼고 헹군다"},
         {"step": 3, "text": "양념장: 간장 3T, 고추장 1T, 고춧가루 1T, 설탕 1.5T, 맛술 1T, 다진마늘 1T, 물 150ml를 섞는다"},
         {"step": 4, "text": "냄비에 닭날개를 담고 양념장을 부어 센불로 끓인다"},
         {"step": 5, "text": "끓어오르면 중불로 줄여 뚜껑 덮고 15분간 조린다"},
         {"step": 6, "text": "뚜껑을 열고 국물을 끼얹어가며 5분 더 조려 윤기나게 완성한다. 깨소금을 뿌린다"}
     ]},
    {"id": 82, "difficulty": 1, "cook_time_min": 15, "servings": 1,
     "tags": ["덮밥", "닭가슴살", "다이어트", "한끼"],
     "steps": [
         {"step": 1, "text": "닭가슴살 1쪽(150g)을 한입 크기로 썰어 소금, 후추, 맛술 1t로 밑간한다"},
         {"step": 2, "text": "소스: 간장 1.5T, 굴소스 1/2T, 설탕 1/2T, 물 2T를 섞는다"},
         {"step": 3, "text": "팬에 식용유 1T를 두르고 닭가슴살을 중불에서 4분 볶아 익힌다"},
         {"step": 4, "text": "양파 1/4개(채썬 것), 파프리카 1/4개를 넣고 1분 볶는다"},
         {"step": 5, "text": "소스를 넣고 1분 더 볶아 걸쭉하게 만든다"},
         {"step": 6, "text": "밥 위에 올리고 대파, 깨소금을 뿌려 완성한다"}
     ]},
    {"id": 83, "difficulty": 2, "cook_time_min": 40, "servings": 1,
     "tags": ["탕", "닭", "보양식", "삼계탕"],
     "steps": [
         {"step": 1, "text": "영계(작은 닭) 1마리 또는 닭다리 2개를 깨끗이 씻는다"},
         {"step": 2, "text": "찹쌀 1/4컵을 30분 불려 준비한다"},
         {"step": 3, "text": "닭 뱃속에 불린 찹쌀, 마늘 3쪽, 대추 2개를 넣는다 (닭다리는 생략)"},
         {"step": 4, "text": "냄비에 닭과 물 1L, 인삼 1뿌리(옵션), 대파 1대를 넣고 센불로 끓인다"},
         {"step": 5, "text": "끓어오르면 거품을 걷고 중약불로 줄여 30분간 끓인다"},
         {"step": 6, "text": "소금, 후추로 간하고 대파 채를 올려 완성한다"}
     ]},
    {"id": 84, "difficulty": 1, "cook_time_min": 20, "servings": 4,
     "tags": ["조림", "연근", "밑반찬", "도시락"],
     "steps": [
         {"step": 1, "text": "연근 200g을 껍질 벗기고 0.5cm 두께로 동그랗게 썬 뒤 식초물에 5분 담근다"},
         {"step": 2, "text": "끓는 물에 연근을 3분 데쳐 건진다"},
         {"step": 3, "text": "팬에 식용유 1/2T를 두르고 연근을 중불에서 1분 볶는다"},
         {"step": 4, "text": "간장 2T, 물엿 1.5T, 설탕 1/2T, 물 100ml를 넣고 끓인다"},
         {"step": 5, "text": "중약불에서 국물이 자작해질 때까지 10분 조린다"},
         {"step": 6, "text": "참기름 1t, 깨소금을 뿌려 완성한다"}
     ]},
    {"id": 85, "difficulty": 1, "cook_time_min": 25, "servings": 4,
     "tags": ["조림", "우엉", "밑반찬", "도시락"],
     "steps": [
         {"step": 1, "text": "우엉 200g을 칼등으로 껍질을 긁어내고 5cm 길이로 채썰어 식초물에 담근다"},
         {"step": 2, "text": "팬에 식용유 1T를 두르고 우엉을 중불에서 3분 볶는다"},
         {"step": 3, "text": "간장 2T, 설탕 1T, 물엿 1T, 맛술 1T, 물 100ml를 넣고 끓인다"},
         {"step": 4, "text": "중약불로 줄여 국물이 거의 없어질 때까지 15분 조린다"},
         {"step": 5, "text": "참기름 1T, 깨소금을 뿌려 완성한다"}
     ]},
    {"id": 86, "difficulty": 1, "cook_time_min": 15, "servings": 2,
     "tags": ["볶음", "고구마줄기", "반찬", "나물"],
     "steps": [
         {"step": 1, "text": "삶은 고구마줄기 200g을 5cm 길이로 자르고 질긴 껍질을 벗긴다"},
         {"step": 2, "text": "팬에 들기름 1T를 두르고 고구마줄기를 중불에서 2분 볶는다"},
         {"step": 3, "text": "다진마늘 1/2T, 국간장 1T를 넣고 1분 더 볶는다"},
         {"step": 4, "text": "물 2T를 넣고 뚜껑 덮어 약불에서 5분간 뭉근하게 볶는다"},
         {"step": 5, "text": "들깨가루 1T, 참기름 1t, 깨소금을 넣어 완성한다"}
     ]},
    {"id": 87, "difficulty": 1, "cook_time_min": 10, "servings": 2,
     "tags": ["볶음", "청경채", "반찬", "건강식"],
     "steps": [
         {"step": 1, "text": "청경채 4~5포기를 반으로 갈라 흐르는 물에 씻어 물기를 뺀다"},
         {"step": 2, "text": "마늘 3쪽을 편으로 썬다"},
         {"step": 3, "text": "팬에 식용유 1T를 두르고 마늘을 약불에서 30초 볶아 향을 낸다"},
         {"step": 4, "text": "청경채를 넣고 센불에서 1~2분 빠르게 볶는다"},
         {"step": 5, "text": "굴소스 1T, 소금 약간으로 간하고 참기름을 살짝 뿌려 완성한다"}
     ]},
    {"id": 88, "difficulty": 1, "cook_time_min": 10, "servings": 1,
     "tags": ["볶음밥", "베이컨", "간편식", "한끼"],
     "steps": [
         {"step": 1, "text": "베이컨 3장을 1cm 폭으로 썰고, 양파 1/4개, 대파 1/3대를 다진다"},
         {"step": 2, "text": "팬에 기름 없이 베이컨을 중불에서 2분 볶아 기름을 뺀다"},
         {"step": 3, "text": "달걀 1개를 풀어 넣고 바로 찬밥 1공기를 올려 함께 볶는다"},
         {"step": 4, "text": "양파를 넣고 간장 1T, 소금·후추로 간하며 2분 볶는다"},
         {"step": 5, "text": "대파, 참기름 1t, 깨소금을 넣어 완성한다"}
     ]},
    {"id": 89, "difficulty": 1, "cook_time_min": 20, "servings": 2,
     "tags": ["분식", "떡볶이", "치즈", "간식"],
     "steps": [
         {"step": 1, "text": "떡볶이 떡 300g을 찬물에 10분 담가 부드럽게 한다"},
         {"step": 2, "text": "양념장: 고추장 2T, 고춧가루 1T, 간장 1T, 설탕 1.5T, 물엿 1T, 다진마늘 1/2T를 섞는다"},
         {"step": 3, "text": "냄비에 물 400ml를 끓이고 양념장을 풀어 떡과 어묵 2장(썬 것)을 넣는다"},
         {"step": 4, "text": "중불에서 7~8분 끓여 떡이 부드러워지면 양배추 2장(큼직하게 썬 것)을 넣는다"},
         {"step": 5, "text": "대파를 송송 썰어 넣고 모짜렐라 치즈(또는 슬라이스 치즈 2장)를 올린다"},
         {"step": 6, "text": "뚜껑을 덮고 1분간 치즈가 녹으면 완성한다"}
     ]},
    {"id": 90, "difficulty": 1, "cook_time_min": 15, "servings": 2,
     "tags": ["면", "메밀", "냉면", "여름"],
     "steps": [
         {"step": 1, "text": "메밀국수(소바) 200g을 끓는 물에 4~5분 삶아 찬물에 여러 번 헹궈 전분을 뺀다"},
         {"step": 2, "text": "쯔유(간장 3T + 맛술 2T + 물 200ml + 가쓰오부시 한줌을 끓여 식힌 것) 또는 시판 쯔유를 준비한다"},
         {"step": 3, "text": "오이 1/3개를 채썰고, 김을 잘게 부순다"},
         {"step": 4, "text": "면을 그릇에 담고 대파 채, 오이, 김가루, 와사비를 올린다"},
         {"step": 5, "text": "차가운 쯔유를 곁들여 면을 찍어 먹거나 부어 먹는다"}
     ]},
]

def main():
    conn = psycopg2.connect(DB_URL)
    cur = conn.cursor()
    for r in RECIPES:
        steps_json = json.dumps(r["steps"], ensure_ascii=False)
        tags_json = json.dumps(r["tags"], ensure_ascii=False)
        cur.execute("""
            UPDATE recipes SET difficulty=%s, cook_time_min=%s, servings=%s,
                tags=%s::jsonb, steps=%s::jsonb WHERE id=%s
        """, (r["difficulty"], r["cook_time_min"], r["servings"], tags_json, steps_json, r["id"]))
        print(f"  ✅ ID {r['id']}: {len(r['steps'])}단계 업데이트")
    conn.commit(); cur.close(); conn.close()
    print(f"\n🎉 배치 9 완료! (ID 81~90, {len(RECIPES)}개 업데이트)")

if __name__ == "__main__":
    main()
