# -*- coding: utf-8 -*-
"""배치 11: ID 101~105 레시피 상세 업데이트 (마지막!)"""
import psycopg2
import json

DB_URL = "postgresql://postgres:WIjbfaRGbyRnfKhKCkpRwggjMLRGbsmj@mainline.proxy.rlwy.net:14763/railway"

RECIPES = [
    {"id": 101, "difficulty": 2, "cook_time_min": 25, "servings": 2,
     "tags": ["국", "황태", "해장", "국물요리"],
     "steps": [
         {"step": 1, "text": "황태채 50g을 찬물에 10분 불린 뒤 물기를 짜고 먹기 좋게 찢는다"},
         {"step": 2, "text": "무 100g을 나박썬다"},
         {"step": 3, "text": "냄비에 참기름 1T를 두르고 황태를 넣어 중불에서 2분 볶는다"},
         {"step": 4, "text": "무를 넣고 1분 볶은 뒤 물 800ml를 붓고 센불로 끓인다"},
         {"step": 5, "text": "끓어오르면 중불로 줄여 15분간 끓인다"},
         {"step": 6, "text": "달걀 1개를 풀어 넣고 다진마늘 1T, 국간장 1T, 소금으로 간한다"},
         {"step": 7, "text": "대파 1/2대를 송송 썰어 넣고 후추를 뿌려 완성한다"}
     ]},
    {"id": 102, "difficulty": 1, "cook_time_min": 15, "servings": 2,
     "tags": ["볶음", "감자", "반찬", "밑반찬"],
     "steps": [
         {"step": 1, "text": "감자 2개(300g)를 껍질 벗기고 0.3cm 두께로 채썰어 물에 5분 담가 전분을 뺀다"},
         {"step": 2, "text": "물기를 빼고 키친타월로 닦는다"},
         {"step": 3, "text": "팬에 식용유 2T를 두르고 감자를 넣어 중불에서 5분 볶는다 (너무 자주 뒤적이지 않기)"},
         {"step": 4, "text": "감자가 투명해지면 소금 1/3t, 설탕 약간으로 간하고 대파 1/3대를 송송 썰어 넣는다"},
         {"step": 5, "text": "참기름 1t, 깨소금을 뿌려 완성한다 (아삭한 식감 유지가 포인트)"}
     ]},
    {"id": 103, "difficulty": 1, "cook_time_min": 15, "servings": 2,
     "tags": ["국", "두부", "국물요리", "간편식"],
     "steps": [
         {"step": 1, "text": "두부 1/2모를 깍둑썰고, 애호박 1/4개를 반달 썬다"},
         {"step": 2, "text": "냄비에 멸치·다시마 육수 600ml를 넣고 끓인다 (또는 물에 국멸치로 육수 우림)"},
         {"step": 3, "text": "끓어오르면 두부와 애호박을 넣는다"},
         {"step": 4, "text": "국간장 1T, 다진마늘 1/2T, 소금으로 간을 맞추고 5분 끓인다"},
         {"step": 5, "text": "달걀 1개를 풀어 넣고 대파를 송송 썰어 넣어 완성한다"}
     ]},
    {"id": 104, "difficulty": 2, "cook_time_min": 25, "servings": 2,
     "tags": ["볶음", "돼지고기", "고추장", "밥반찬"],
     "steps": [
         {"step": 1, "text": "돼지고기(앞다리살 또는 목살) 300g을 먹기 좋게 썬다"},
         {"step": 2, "text": "양념: 고추장 2T, 간장 1T, 설탕 1T, 맛술 1T, 다진마늘 1T, 생강즙 1/2t, 참기름 1T를 섞는다"},
         {"step": 3, "text": "고기에 양념을 넣고 버무려 15분 재운다"},
         {"step": 4, "text": "양파 1개를 굵게 채썰고, 대파 1대를 어슷 썰고, 고추 1개를 썬다"},
         {"step": 5, "text": "팬에 식용유 1T를 두르고 센불에서 양념고기를 3~4분 볶는다"},
         {"step": 6, "text": "양파를 넣고 2분 볶은 뒤 대파, 고추를 넣어 1분 더 볶아 깨소금을 뿌려 완성한다"}
     ]},
    {"id": 105, "difficulty": 1, "cook_time_min": 15, "servings": 1,
     "tags": ["간편식", "치킨너겟", "아이", "한끼"],
     "steps": [
         {"step": 1, "text": "냉동 치킨너겟 6~8개를 준비한다"},
         {"step": 2, "text": "에어프라이어 180도에서 10~12분 굽는다 (또는 팬에 기름을 두르고 중불에서 양면 노릇하게 굽기)"},
         {"step": 3, "text": "중간에 한 번 뒤집어준다"},
         {"step": 4, "text": "밥 1공기와 함께 접시에 담는다"},
         {"step": 5, "text": "케첩, 허니머스타드 등 소스를 곁들이고 샐러드나 피클을 함께 내어 완성한다"}
     ]},
]

def main():
    conn = psycopg2.connect(DB_URL)
    cur = conn.cursor()
    for r in RECIPES:
        steps_json = json.dumps(r["steps"], ensure_ascii=False)
        tags_json = json.dumps(r["tags"], ensure_ascii=False)
        cur.execute("""
            UPDATE recipes SET difficulty=%s, cook_time_min=%s, servings=%s,
                tags=%s::jsonb, steps=%s::jsonb WHERE id=%s
        """, (r["difficulty"], r["cook_time_min"], r["servings"], tags_json, steps_json, r["id"]))
        print(f"  ✅ ID {r['id']}: {len(r['steps'])}단계 업데이트")
    conn.commit(); cur.close(); conn.close()
    print(f"\n🎉 배치 11 완료! (ID 101~105, {len(RECIPES)}개 업데이트)")
    print(f"\n🎊🎊🎊 전체 106개 레시피 상세 업데이트 완료! 🎊🎊🎊")

if __name__ == "__main__":
    main()
