# -*- coding: utf-8 -*-
"""배치 10: ID 91~100 레시피 상세 업데이트"""
import psycopg2
import json

DB_URL = "postgresql://postgres:WIjbfaRGbyRnfKhKCkpRwggjMLRGbsmj@mainline.proxy.rlwy.net:14763/railway"

RECIPES = [
    {"id": 91, "difficulty": 2, "cook_time_min": 25, "servings": 1,
     "tags": ["덮밥", "오므라이스", "양식", "한끼"],
     "steps": [
         {"step": 1, "text": "양파 1/4개, 당근 1/4개, 햄 50g을 잘게 다진다"},
         {"step": 2, "text": "팬에 식용유 1T를 두르고 다진 채소와 햄을 중불에서 2분 볶는다"},
         {"step": 3, "text": "찬밥 1공기를 넣고 케첩 2T, 소금·후추로 간하며 2분 볶아 케첩라이스를 만든다"},
         {"step": 4, "text": "그릇에 케첩라이스를 타원형으로 담는다"},
         {"step": 5, "text": "달걀 3개를 풀어 소금 약간 넣고 팬에 버터를 녹인 뒤 약불에서 얇게 부친다"},
         {"step": 6, "text": "반숙 상태에서 접어 케첩라이스 위에 올리고 가운데를 칼로 갈라 벌린다"},
         {"step": 7, "text": "케첩을 뿌리고 파슬리를 올려 완성한다"}
     ]},
    {"id": 92, "difficulty": 2, "cook_time_min": 30, "servings": 2,
     "tags": ["김밥", "소시지", "도시락", "간식"],
     "steps": [
         {"step": 1, "text": "소시지 4개를 길이로 반 갈라 팬에 노릇하게 굽는다"},
         {"step": 2, "text": "달걀 2개를 풀어 소금 약간 넣고 팬에 얇게 부쳐 길게 자른다"},
         {"step": 3, "text": "시금치 100g을 데쳐 찬물에 헹구고 참기름, 소금으로 무친다"},
         {"step": 4, "text": "단무지, 우엉조림을 길게 준비한다"},
         {"step": 5, "text": "밥 2공기에 참기름 1T, 소금 1/2t, 깨소금을 넣어 섞는다"},
         {"step": 6, "text": "김 위에 밥을 얇게 펴고 소시지, 달걀, 시금치, 단무지를 올려 단단히 만다"},
         {"step": 7, "text": "참기름을 김 겉면에 바르고 먹기 좋게 썰어 완성한다"}
     ]},
    {"id": 93, "difficulty": 1, "cook_time_min": 10, "servings": 2,
     "tags": ["볶음", "어묵", "반찬", "밑반찬"],
     "steps": [
         {"step": 1, "text": "어묵 200g을 먹기 좋게 썰고 끓는 물에 30초 데쳐 기름기를 뺀다"},
         {"step": 2, "text": "양파 1/4개를 채썰고, 청양고추 1개, 대파 1/3대를 송송 썬다"},
         {"step": 3, "text": "양념: 간장 1.5T, 고춧가루 1/2T, 설탕 1/2T, 물엿 1/2T, 다진마늘 1/2t를 섞는다"},
         {"step": 4, "text": "팬에 식용유 1/2T를 두르고 어묵과 양파를 중불에서 2분 볶는다"},
         {"step": 5, "text": "양념을 넣고 1분 볶은 뒤 대파, 청양고추, 참기름, 깨소금을 넣어 완성한다"}
     ]},
    {"id": 94, "difficulty": 2, "cook_time_min": 20, "servings": 2,
     "tags": ["구이", "돼지고기", "목살", "밥반찬"],
     "steps": [
         {"step": 1, "text": "돼지 목살 300g을 1cm 두께로 썬다"},
         {"step": 2, "text": "소금, 후추를 양면에 뿌리고 10분간 재운다"},
         {"step": 3, "text": "팬을 센불로 달궈 기름 없이 목살을 올린다 (목살 자체 기름으로 충분)"},
         {"step": 4, "text": "한 면당 3~4분씩 노릇하게 구워 뒤집는다"},
         {"step": 5, "text": "가위로 먹기 좋게 잘라 쌈채소, 쌈장(된장 1T + 고추장 1T + 참기름 1t)과 함께 낸다"}
     ]},
    {"id": 95, "difficulty": 2, "cook_time_min": 25, "servings": 2,
     "tags": ["볶음", "소고기", "불고기", "한식"],
     "steps": [
         {"step": 1, "text": "소고기 불고기용 300g을 키친타월로 핏물을 닦는다"},
         {"step": 2, "text": "양념: 간장 3T, 설탕 1.5T, 배즙 2T, 다진마늘 1T, 참기름 1T, 후추를 섞는다"},
         {"step": 3, "text": "고기에 양념을 넣고 주물러 30분 재운다"},
         {"step": 4, "text": "양파 1개를 채썰고, 대파 1대를 어슷 썰고, 표고버섯 2개를 채썬다"},
         {"step": 5, "text": "팬에 센불에서 양념한 고기를 펼쳐 놓고 3분 볶는다"},
         {"step": 6, "text": "양파, 버섯을 넣고 2분 더 볶아 대파를 넣고 참기름, 깨소금으로 마무리한다"}
     ]},
    {"id": 96, "difficulty": 2, "cook_time_min": 15, "servings": 2,
     "tags": ["무침", "오징어", "매운맛", "안주"],
     "steps": [
         {"step": 1, "text": "오징어 1마리를 내장 빼고 몸통에 칼집을 넣은 뒤 한입 크기로 썬다"},
         {"step": 2, "text": "끓는 물에 오징어를 1분 데쳐 찬물에 헹궈 물기를 뺀다 (너무 오래 삶으면 질겨짐)"},
         {"step": 3, "text": "양배추 2장, 오이 1/3개를 채썰고 양파 1/4개를 얇게 썬다"},
         {"step": 4, "text": "양념: 고추장 1.5T, 고춧가루 1T, 식초 1T, 설탕 1T, 다진마늘 1/2T, 참기름 1T를 섞는다"},
         {"step": 5, "text": "오징어와 채소에 양념을 넣고 골고루 무쳐 깨소금을 뿌려 완성한다"}
     ]},
    {"id": 97, "difficulty": 1, "cook_time_min": 20, "servings": 2,
     "tags": ["간식", "고구마", "튀김", "달콤"],
     "steps": [
         {"step": 1, "text": "고구마 2개(300g)를 껍질 벗기고 한입 크기로 깍둑썰어 물에 5분 담가 전분을 뺀다"},
         {"step": 2, "text": "물기를 닦고 팬에 식용유를 넉넉히(고구마가 반쯤 잠길 정도) 두른다"},
         {"step": 3, "text": "중불(170도)에서 고구마를 5~6분 튀기고 건져 기름을 뺀다"},
         {"step": 4, "text": "팬의 기름을 버리고 설탕 3T, 물 1T를 넣어 약불에서 녹인다"},
         {"step": 5, "text": "설탕이 캐러멜색이 되면 튀긴 고구마를 넣고 빠르게 버무려 검은깨를 뿌려 완성한다"}
     ]},
    {"id": 98, "difficulty": 1, "cook_time_min": 20, "servings": 2,
     "tags": ["찜", "단호박", "건강식", "간식"],
     "steps": [
         {"step": 1, "text": "단호박 1개를 반으로 갈라 씨와 속을 파낸다"},
         {"step": 2, "text": "찜기에 물을 끓이고 단호박을 넣어 15~20분 찐다 (젓가락이 쉽게 들어가면 완성)"},
         {"step": 3, "text": "또는 전자레인지에 랩을 씌워 7~8분 돌린다"},
         {"step": 4, "text": "그대로 먹거나 꿀 또는 설탕을 살짝 뿌려 완성한다"},
         {"step": 5, "text": "잘라서 반찬으로 먹거나 으깨서 단호박 샐러드로 활용한다"}
     ]},
    {"id": 99, "difficulty": 1, "cook_time_min": 15, "servings": 2,
     "tags": ["면", "잔치국수", "국물요리", "한식"],
     "steps": [
         {"step": 1, "text": "물 1L에 멸치 한줌, 다시마 1조각을 넣고 10분 끓여 육수를 만든 뒤 건더기를 건진다"},
         {"step": 2, "text": "육수에 국간장 1T, 소금으로 간을 맞춘다"},
         {"step": 3, "text": "소면 200g을 끓는 물에 3~4분 삶아 찬물에 여러 번 헹군다"},
         {"step": 4, "text": "애호박 1/3개를 채썰어 팬에 살짝 볶고, 달걀지단을 부쳐 채썬다"},
         {"step": 5, "text": "그릇에 면을 담고 뜨거운 육수를 부어 애호박, 달걀지단, 김가루를 올려 완성한다"}
     ]},
    {"id": 100, "difficulty": 2, "cook_time_min": 25, "servings": 2,
     "tags": ["비빔밥", "된장", "건강식", "한식"],
     "steps": [
         {"step": 1, "text": "시금치 100g을 데쳐 참기름, 소금으로 무치고, 콩나물 100g을 삶아 참기름, 소금으로 무친다"},
         {"step": 2, "text": "당근 1/2개를 채썰어 팬에 소금 약간 넣어 볶는다"},
         {"step": 3, "text": "애호박 1/3개를 반달 썰어 소금 뿌려 물기 빼고 팬에 볶는다"},
         {"step": 4, "text": "양념된장: 된장 1.5T, 고추장 1/2T, 참기름 1T, 다진마늘 1/2t, 깨소금을 섞는다"},
         {"step": 5, "text": "밥 위에 나물을 돌려 담고 가운데 달걀프라이를 올린다"},
         {"step": 6, "text": "양념된장을 올리고 골고루 비벼 먹는다"}
     ]},
]

def main():
    conn = psycopg2.connect(DB_URL)
    cur = conn.cursor()
    for r in RECIPES:
        steps_json = json.dumps(r["steps"], ensure_ascii=False)
        tags_json = json.dumps(r["tags"], ensure_ascii=False)
        cur.execute("""
            UPDATE recipes SET difficulty=%s, cook_time_min=%s, servings=%s,
                tags=%s::jsonb, steps=%s::jsonb WHERE id=%s
        """, (r["difficulty"], r["cook_time_min"], r["servings"], tags_json, steps_json, r["id"]))
        print(f"  ✅ ID {r['id']}: {len(r['steps'])}단계 업데이트")
    conn.commit(); cur.close(); conn.close()
    print(f"\n🎉 배치 10 완료! (ID 91~100, {len(RECIPES)}개 업데이트)")

if __name__ == "__main__":
    main()
