# 🌤️ 날씨 기반 식단 추천 기능 배포 가이드

## 파일 배치
```
C:\Projects\meal-planner\
├── backend\app\services\
│   ├── weather_service.py     ← 새 파일 (복사)
│   └── menu_service.py        ← 덮어쓰기
├── backend\app\api\
│   └── menu.py                ← 덮어쓰기
└── backend\static\
    └── index.html             ← 패치 스크립트로 수정
```

## 적용 순서

### 1단계: 백엔드 파일 복사
```powershell
copy weather_service.py backend\app\services\weather_service.py
copy menu_service.py backend\app\services\menu_service.py
copy menu_api.py backend\app\api\menu.py
```

### 2단계: httpx 패키지 설치 (날씨 API 호출용)
```powershell
pip install httpx
```
Railway에서도 requirements.txt에 httpx 추가 필요:
```powershell
# requirements.txt에 httpx 추가
Add-Content backend\requirements.txt "httpx"
```

### 3단계: 프론트엔드 패치
```powershell
python patch_frontend_weather.py
```

### 4단계: Git 커밋 & Railway 배포
```powershell
git add -A
git commit -m "feat: 날씨 기반 식단 추천 v1.4.0"
git push
```

## 기능 설명

### 날씨 → 음식 매핑 규칙
| 조건 | 추천 음식 | 보너스 |
|------|----------|--------|
| 기온 ≤ 0°C | 탕/찌개/국/죽 | +12점 |
| 기온 1~10°C | 국물요리/조림/볶음 | +12점 |
| 기온 21~27°C | 무침/비빔밥/샐러드/볶음밥 | +12점 |
| 기온 ≥ 28°C | 면/냉면/비빔밥/샐러드 | +12점 |
| 비 오는 날 | 전/칼국수/수제비/분식 | +15점 |
| 눈 오는 날 | 국/탕/찌개/보양식 | +12점 |
| 봄 (3~5월) | 나물/무침/비빔밥 | +8점 |
| 여름 (6~8월) | 면/냉면/비빔밥/샐러드 | +8점 |
| 가을 (9~11월) | 볶음/조림/구이/찌개 | +8점 |
| 겨울 (12~2월) | 국/탕/찌개/전/보양식 | +8점 |

### API 엔드포인트
- `GET /api/weather/weekly?week_start=2026-02-09` - 주간 날씨 조회
- 기존 `POST /api/menu/generate` - 날씨 자동 반영

### 날씨 데이터 소스
- Open-Meteo API (무료, API키 불필요, 서울 기본)
- 1시간 캐싱으로 API 호출 최소화
- 예보 범위 밖(7일 초과)은 계절 기본값 사용
